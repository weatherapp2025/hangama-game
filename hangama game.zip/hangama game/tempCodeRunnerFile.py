
    word = random.choice(words).lower()
    word_letters = set(word)
    guessed_letters = set()
    attempts = 6
    
    print("\n🎮 Welcome to Hangman Game! 🎮")
    print(f"You have {attempts} attempts to guess the word.\n")
    
    while attempts > 0 and word_letters:
        # Display current progress
        print(f"\nAttempts remaining: {attempts}")
        print(f"Guessed letters: {' '.join(sorted(guessed_letters)) if guessed_letters else 'None'}")
        
        # Show word with guessed letters
        display_word = ' '.join([letter if letter in guessed_letters else '_' for letter in word])
        print(f"Word: {display_word}")
        
        # Get user input
        guess = input("\nGuess a letter: ").lower()
        
        # Validate input
        if len(g❌ Invalid input! Please enter a single letter.")
            continueuess) != 1 or not guess.isalpha():
            print("