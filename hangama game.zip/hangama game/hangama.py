import random

def hangman():
    """Main hangman game function"""
    # Predefined word list (5 words)
    words = ['python', 'javascript', 'programming', 'developer', 'algorithm']
    
    # Select random word
    word = random.choice(words).lower()
    word_letters = set(word)
    guessed_letters = set()
    attempts = 6
    
    print("\n🎮 Welcome to Hangman Game! 🎮")
    print(f"You have {attempts} attempts to guess the word.\n")
    
    while attempts > 0 and word_letters:
        # Display current progress
        print(f"\nAttempts remaining: {attempts}")
        print(f"Guessed letters: {' '.join(sorted(guessed_letters)) if guessed_letters else 'None'}")
        
        # Show word with guessed letters
        display_word = ' '.join([letter if letter in guessed_letters else '_' for letter in word])
        print(f"Word: {display_word}")
        
        # Get user input
        guess = input("\nGuess a letter: ").lower()
        
        # Validate input
        if len(guess) != 1 or not guess.isalpha():
            print("❌ Invalid input! Please enter a single letter.")
            continue
        
        if guess in guessed_letters:
            print("⚠️ You already guessed that letter!")
            continue
        
        # Process guess
        guessed_letters.add(guess)
        
        if guess in word_letters:
            word_letters.remove(guess)
            print("✅ Correct guess!")
        else:
            attempts -= 1
            print(f"❌ Wrong guess! {attempts} attempts left.")
    
    # Game over
    print("\n" + "="*40)
    if not word_letters:
        print(f"🎉 Congratulations! You won! The word was '{word}'")
    else:
        print(f"💀 Game Over! The word was '{word}'")
    print("="*40 + "\n")

if __name__ == "__main__":
    while True:
        hangman()
        play_again = input("Play again? (y/n): ").lower()
        if play_again != 'y':
            print("Thanks for playing! 👋")
            break